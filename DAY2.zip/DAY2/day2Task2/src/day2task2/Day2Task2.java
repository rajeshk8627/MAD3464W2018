/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2task2;

/**
 *
 * @author macstudent
 */
public class Day2Task2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        person one = new person();
        
        //one.displayData();
        
        
        person nancy = new person("nancy, "dhot", 24);"
        //nancy.displayData():)   
        
        
        Person nancy = new Person(nancy);
        //nan.displayData();
        
        
        
       // Employee e1 = new Employee(1450.87);
       // e1.display();
        
        
        Employee E2 = new Employee();
        E2.display();
        E2.firstName = "nancy";
        E2.lastName = "dhot";
        E2.age = "24";
        E2.salary = 10000;
        //E2.displayData();
        E2.display();
        
        //method overriding
        Employee E3 = new Employee();
        E3.read();
        E3.display();
        
        
        
        
       // System.out.println("Last name :" + E2.lastName);
        
        
        
        
    }
    
}