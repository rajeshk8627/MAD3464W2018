
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Employee extends Person {
    
    double salary;
    
    Employee(){
        super();
        this.salary = 14;
    }
     Employee(String fname, String lname, int age, double pay){
         super(fname,lname,age);
         this.salary = pay;
         
     }
     void read(){
        // super.readData();
         Scanner input = new Scanner(System.in);
         this.salary = input.nextDouble();
     }
     
     
     void display(){
        // super.displayData();
         System.out.println("last name");
         
     }
}
