
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class NewClass {
    public static void main(String[] args) {
        Bank myBank = new Bank();
        
        System.out.println("Bank ID : " + myBank.bankID);
        System.out.println("Bank Name : " +myBank.bankName);
        
        Bank yourBank = new Bank();
        myBank.bankID = 1231;
        myBank.bankName = "RBC";
        
        
        System.out.println("Bank ID : " + myBank.bankID);
        System.out.println("Bank Name : " + myBank.bankName);
                
                
              myBank.getBankName();
    
    yourBank.setBankName("ICICI");
    yourBank.getBankName();
    
    Scanner myInput = new Scanner(System.in);
    String name;
    
    System.out.println("Enter bank Name : ");
    name = myInput.nextLine();
    
    
    yourBank.setBankName(name);
    yourBank.getBankName();
    
    
    
    
    Arithmetic operation1 = new Arithmetic();
    
    System.out.println("Output of integer addition : " +operation1.addition(1,20));
    
    System.out.println("Output of float : " +operation1.addition(10.23f, 20.23f));
    
    System.out.println("Output of integer : " +operation1.addition(10,20,30));
    
    
    System.out.println("Output of multiplication: " + operation1.multiplication(10,20,30));
    
    
    
    Arithmetic.multiplication(10,20);
    //Arithmetic.addition(10,20);
    
    Arithmetic.n1 = 20;
   // Arithmetic.n2 = 20;
    System.out.println(Arithmetic.n1+ " " + Arithmetic.n2);
    }
    
}
