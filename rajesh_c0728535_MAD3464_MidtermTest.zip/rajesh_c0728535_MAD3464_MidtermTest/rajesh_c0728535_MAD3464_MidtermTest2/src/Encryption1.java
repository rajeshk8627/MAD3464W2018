/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */

public class Encryption1 
{
    public static void main(String[] args) 
    {
     String a = "ZANIL";

     for (int i=0; i < a.length(); i++)
      {
        if (i % 2 != 0)
        {
          a = a.substring(0,i-1) + "1" + a.substring(i, a.length());
        }
      }
     
      System.out.println(a);

   
    } 
}
