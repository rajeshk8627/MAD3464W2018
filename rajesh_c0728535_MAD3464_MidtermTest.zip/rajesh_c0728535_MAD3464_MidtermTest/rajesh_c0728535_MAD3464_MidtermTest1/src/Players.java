/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */

import java.util.Scanner;

public class Players
{
    String PlayerID;
    String PlayerName;
    
    Players()
    {
        this.PlayerID = "Unknown";
        this.PlayerName = "Unknown";
    }
    
    Players(String PID, String PNM)
    {
        this.PlayerID = PID;
        this.PlayerName = PNM;
    }   
    
    Players(Players object)
    {
        this.PlayerID = object.PlayerID;
        this.PlayerName = object.PlayerName;
    }
    
    void readData()
    {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter Player ID : ");
        this.PlayerID = input.nextLine();
        
        System.out.println("Enter Player Name : ");
        this.PlayerName = input.nextLine();
    }
    
    void displayData()
    {
        System.out.println("Player ID : " + this.PlayerID);
        System.out.println("Player Name : " + this.PlayerName);
    }
}



